package pc;

import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */


public class ClassCategorie {
    
    
   public String nomcat;
   public  ArrayList<Produit> Listeprod;
   
   public ClassCategorie(String nomCat)
    {
        this.nomcat = nomCat;
        this.Listeprod = new ArrayList<Produit>();
    }
    
    public void addProd(Produit p)
    {
      this.Listeprod.add(p);
    }
    
}

