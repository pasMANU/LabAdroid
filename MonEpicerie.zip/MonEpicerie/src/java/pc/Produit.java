package pc;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */
public class Produit  {
    
    private String id;
    private String Nom;
    private String Description;
    private int prix;
    private String img;
    
public Produit(){
    
    this.id="";
    this.prix=0;
    this.Nom="";
    this.Description="";
    this.img="";


}

public Produit(String id, int prix, String Nom, String Description , String img){
    
    this.id= id;
    this.Nom= Nom;
    this.Description=Description;
    this.img=img;
    this.prix=prix;
           
}

public String getid(){
    
    return this.id;

}

public  int getprix(){
    return this.prix;
}
    

public String getNom(){
    
  return this.Nom;

}
    
public String getDescription(){
    return this.Description;
}

public String getimg(){
    return this.img;

}

public void Setid(String id){


this.id= id;
}

public void Setprix(int  prix){


this.prix= prix;
}

public void SetNom(String  Nom){


this.Nom=Nom;
}

public void SetDescriptiom(String  Description){


this.Description=Description;
}


public void Setimg(String  img){


this.img=img;
}


}

