package pc;


import pc.Produit;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */
public class TableDataGetWay {
      private PreparedStatement SelectAll;
   public Connection  connect;
   public  ResultSet result;
    
    public TableDataGetWay()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
           connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/s6_app_wep","root","");
        } catch (Exception ex) {
              out.println(ex);
          } 
    }
     public ArrayList<Produit> selectprod(String nomcat) 
    {
          ArrayList<Produit>listP = new ArrayList<>();
          try{
               String RequeteSelection ="select * from produitr,categorie WHERE produit.idCat=categorie.idCat and categorie.NomCat='"+nomcat+"';";
            
            SelectAll = connect.prepareStatement(RequeteSelection);
             result = SelectAll.executeQuery();
            
               while(result.next())
                   
                   
            {
               Produit admall =new Produit(result.getString("Id_prod"),result.getInt("prix"),result.getString("nom"),result.getString("description"),result.getString("img"));
               
               //listP.add( neProduitw ();
               listP.add(admall);
            }
            
          }
          catch(SQLException ex){
              Logger.getLogger(TableDataGetWay.class.getName()).log(Level.SEVERE, null, ex);
          }
        return listP;
    }
}